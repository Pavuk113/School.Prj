let users = [];

fetch("users.json")
  .then(res => res.json())
  .then(data => users = data);

const loginBtn = document.getElementById("loginBtn");
const logoutBtn = document.getElementById("logoutBtn");

loginBtn.onclick = function() {
  let username = document.getElementById("username").value;
  let password = document.getElementById("password").value;
  let error = document.getElementById("error");

  let user = users.find(u => u.username === username && u.password === password);

  if (user) {
    document.getElementById("login-container").style.display = "none";
    document.getElementById("cabinet-container").style.display = "block";
    document.getElementById("welcome").innerText = "Добро пожаловать, " + user.name + "!";
    document.getElementById("email").innerText = "Email: " + user.email;
    error.innerText = "";
  } else {
    error.innerText = "Неверный логин или пароль!";
  }
};

logoutBtn.onclick = function() {
  document.getElementById("cabinet-container").style.display = "none";
  document.getElementById("login-container").style.display = "block";
};